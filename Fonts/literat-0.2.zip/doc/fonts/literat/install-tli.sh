#!/bin/bash

set -e
unzip -L literat.zip psfonts/*

cd psfonts
mv lit55_is.afm rtlir6i.afm
mv lit55_t1.afm rtlir8t.afm
mv lit55_ts.afm rtlir8c.afm
mv lit56_is.afm rtliri6i.afm
mv lit56_t1.afm rtliri8t.afm
mv lit56_ts.afm rtliri8c.afm
mv lit75_is.afm rtlib6i.afm
mv lit75_t1.afm rtlib8t.afm
mv lit75_ts.afm rtlib8c.afm
mv lit76_is.afm rtlibi6i.afm
mv lit76_t1.afm rtlibi8t.afm
mv lit76_ts.afm rtlibi8c.afm

mv lit55_is.pfb rtlir6i.pfb
mv lit55_t1.pfb rtlir8t.pfb
mv lit55_ts.pfb rtlir8c.pfb
mv lit56_is.pfb rtliri6i.pfb
mv lit56_t1.pfb rtliri8t.pfb
mv lit56_ts.pfb rtliri8c.pfb
mv lit75_is.pfb rtlib6i.pfb
mv lit75_t1.pfb rtlib8t.pfb
mv lit75_ts.pfb rtlib8c.pfb
mv lit76_is.pfb rtlibi6i.pfb
mv lit76_t1.pfb rtlibi8t.pfb
mv lit76_ts.pfb rtlibi8c.pfb
cd ..

TEXMF=`kpsewhich -expand-var='$TEXMFMAIN'`
mkdir -p $TEXMF/{dvips,tex/latex,fonts/tfm/paragrap,fonts/vf/paragrap,fonts/type1/paragrap}/literat
mv dvips/* $TEXMF/dvips/literat
mv tex/*.{fd,sty} $TEXMF/tex/latex/literat
mv {tfm,tfm-raw}/* $TEXMF/fonts/tfm/paragrap/literat
mv vf/* $TEXMF/fonts/vf/paragrap/literat
mv psfonts/*.pfb $TEXMF/fonts/type1/paragrap/literat

#mkdir $TEXMF/{fonts/afm/paragrap,doc/latex}/literat
#mv psfonts/*.afm $TEXMF/fonts/afm/paragrap/literat
#mv tex/*.tex $TEXMF/doc/latex/literat

#echo "p +tli.map" > $TEXMF/dvips/config/config.tli
#echo "map +tli.map" >> $TEXMF/pdftex/base/pdftex.cfg

mktexlsr
